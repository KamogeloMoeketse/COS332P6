#!/usr/bin/env python3

import socket
import ssl
import base64
import cgi
import os
import http.cookies

print("Content-type:text/html\r\n\r\n")
print("<html>")
print("<head>")
print("<title>Email Form</title>")
print("</head>")
print("<body>")
print("<h2>Enter your email</h2>")
print("<form method='post' action=''>")
print("Email: <input type='text' name='email'>")
print("<input type='submit' name='submit' value='Send Email'>")
print("</form>")

# Get the value of a specific cookie
score_file = "score.txt"

def get_score_from_file():
    try:
        # Open the file in read mode to read the current score
        with open(score_file , 'r') as file:
            score = int(file.read().strip())
    except FileNotFoundError:
        # If the file doesn't exist, start with score 0
        score = 0
    # print(score)
    return score

score = get_score_from_file()



name = ""
student_number = ""
try:
    with open('userinfo.txt', 'r') as user_file:
        lines = user_file.readlines()
        for line in lines:
            if line.startswith("Name:"):
                name = line.split(":")[1].strip()
            elif line.startswith("Student Number:"):
                student_number = line.split(":")[1].strip()
except OSError as e:
    print(f"Error reading from userinfo.txt: {e}")

form = cgi.FieldStorage()

if "submit" in form:
    email = form.getvalue("email")
    if not email:
        print("<p style='color:red;'>Please enter your email!</p>")
    else:
        # Proceed with the rest of your code here
        # SMTP server settings
        smtp_server = 'localhost'
        smtp_port = 25

        # Email content
        sender_email = "332server@localhost"
        receiver_email = email + "@localhost"
        subject = "Test Email"
        body = "Thank you for playing!\nName: " + name + '\nStudent number: ' + student_number + '\nScore:' + str(score)

        # Construct email message
        email_message = f"From: {sender_email}\r\nTo: {receiver_email}\r\nSubject: {subject}\r\n\r\n{body}\r\n.\r\n"

        # Connect to SMTP server
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_socket:
            server_socket.connect((smtp_server, smtp_port))
            server_socket.recv(1024)  # Receive server greeting

            # Send HELO command
            server_socket.sendall(b"HELO kamogelo\r\n")
            server_socket.recv(1024)

            # Send MAIL FROM command
            server_socket.sendall(f"MAIL FROM:<{sender_email}>\r\n".encode())
            server_socket.recv(1024)

            # Send RCPT TO command
            server_socket.sendall(f"RCPT TO:<{receiver_email}>\r\n".encode())
            server_socket.recv(1024)

            # Send DATA command
            server_socket.sendall(b"DATA\r\n")
            server_socket.recv(1024)

            # Send email content
            server_socket.sendall(email_message.encode())
            server_socket.recv(1024)

            # Send QUIT command
            server_socket.sendall(b"QUIT\r\n")
            server_socket.recv(1024)

        print("Email sent successfully")

        print(f"<p>Email received: {email}</p>")
        try:
            with open('score.txt', 'w') as val_file:
                val_file.write(str(0))
        except OSError as e:
            print(f"Error writing to score.txt: {e}")

print("</body>")
print("</html>")



